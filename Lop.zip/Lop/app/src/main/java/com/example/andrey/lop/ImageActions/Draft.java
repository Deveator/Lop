package com.example.andrey.lop.ImageActions;

import org.opencv.core.Mat;
import org.opencv.dnn.Net;

public class Draft {

    public static Mat getDraft(Mat mImg){

        Mat img = new Mat();
       // Net net = readNet(model, config, framework);



        return img;

    }
}
