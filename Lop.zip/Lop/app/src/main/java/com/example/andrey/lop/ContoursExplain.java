package com.example.andrey.lop;

public class ContoursExplain {

    // this class explain how to get Point value from contours
    /*
    contours.get(i).convertTo(t, CV_32SC2);
    int y = t.rows();
    int w = t.cols();
    double[] ft = t.get(0, 0);
    double b = ft[0];
    double b2 = ft[1];
    */
}
